package com.example.asbah.testapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class fourthActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);
    }
}
