package com.example.asbah.testapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
public class MainActivity extends AppCompatActivity {
    Button btn_go;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        OnClickButtonListener();                //call this function when button is pressed
    }

    public void OnClickButtonListener() {
        btn_go = (Button) findViewById(R.id.button);
        btn_go.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //when button is clicked move to second activity
                        Intent intent1 = new Intent("com.example.asbah.testapp.secondActivity");
                        startActivity(intent1);
                    }
                }
        );
    }


}
